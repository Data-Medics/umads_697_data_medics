# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['data_medics_capstone', 'data_medics_capstone.pipeline']

package_data = \
{'': ['*']}

install_requires = \
['numpy>=1.20.1,<2.0.0',
 'pandas>=1.3.3,<2.0.0',
 'pytz>=2021.1,<2022.0',
 'scikit-learn>=1.0,<2.0']

setup_kwargs = {
    'name': 'data-medics-capstone',
    'version': '0.0.1',
    'description': '',
    'long_description': None,
    'author': 'tyler zupan',
    'author_email': 'jtzupan@umich.edu',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<3.10',
}


setup(**setup_kwargs)
